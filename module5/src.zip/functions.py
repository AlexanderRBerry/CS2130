def geometric_sequence(n, start, ratio):
    """
    Computes the first n terms of a geometric sequence.

    :param n: Number of terms to compute in the sequence (integer)
    :param start: Initial term of the sequence (double)
    :param ratio: Common ratio for the geometric sequence (double)

    :return: A list containing the first n terms of the geometric
    sequence, rounded to two decimal places.
    """
    geoSequence = [start]
    for i in range(1, n):
        geoSequence.append((geoSequence[i - 1] * ratio))
    return [round(x, 2) for x in geoSequence]


def arithmetic_sequence(n, start, difference):
    """
    Compute the first n terms of an arithmetic sequence.

    :param n: This parameter specifies how many terms to compute.
    :param start: This parameter specifies the initial term of the sequence.
    :param difference: This parameter specifies the common difference for the arithmetic sequence.

    :return: A list containing the computed terms of the arithmetic sequence, rounded to two decimal places.
    """
    arSequence = [start]
    for i in range(1, n):
        arSequence.append(arSequence[i - 1] + difference)
    return[round(x, 2) for x in arSequence]

def div_mod(dividend, divisor):
    """
    Perform integer division using the algorithm shown in Definition 10.1.3
    and return the quotient and remainder.

    :param dividend: The number to be divided.
    :param divisor: The number to divide by.

    :return: A tuple containing the quotient (whole number portion of
    integer division) and the remainder.
    """
    q = 0
    r = dividend
    if dividend >= 0:
        while r >= divisor:
            q = q + 1
            r = r - divisor
    else:
        while r < 0:
            q = q - 1
            r = r + divisor
    return q, r

def gcd(x, y):
    """
    Calculate the greatest common divisor (GCD) of two positive integers
    using the algorithm shown in Figure 10.5.1.

    :param x: The first positive integer.
    :param y: The second positive integer.

    :return: The greatest common divisor of the two integers.
    """
    if y == x:
        tempVal = x
        x = y
        y = tempVal
    r = y % x

    while r != 0:
        y = x
        x = r
        r = y % x

    return x

def lcm(x, y):
    """
    Calculate the least common multiple (LCM) of two positive integers.

    :param x: The first positive integer.
    :param y: The second positive integer.

    :return: The least common multiple of the two integers.
    """
    return (x * y)/ gcd(x, y)
