#Utility class to perform basic tasks

def hello(name="World"):
    print(f'Hello {name}')

def add(x, y):
    return x + y

def sub(x, y):
    #Implement this method
    #Takes two numbers x and y and
    #returns the result x - y
    return x - y